package ast;

public interface Declaration extends Visitable {}
