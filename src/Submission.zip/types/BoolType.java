package types;

public class BoolType extends Type{
    public String toString(){
        return "bool";
    }
}
